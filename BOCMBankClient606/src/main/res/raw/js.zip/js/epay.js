// 

var PGWPortal="https://ebspay.boc.cn/PGWPortal/B2CMobileRecvOrder.do";var BaseUrl="https://mbs.boc.cn/BOCWapBank/";var BaseImgUrl="https://mbs.boc.cn/BOCWapBank/ImageValidation/";var HomeUrl=["http://mbs.boc.cn","http://mbs.boc.cn/BOCWapBank/WEBSPortalMenuNew.do"];var BackUrl="";var WYOMS="http://mpay.we360.com/interface/1.0/cmwap12/acceptOrder.jsp";var SaveOrderUrl="http://mpay.we360.com/interface/1.0/cmwap12/saveOrder.jsp"
var RETURL="";var epay=function(type){createDiv("epay_result","card","");if(type=="WYOMS"){formSubmit(WYOMS,null,"w");}
else{var dataBox=$$("#dataBox");BackUrl=$$("@orderUrl").value;formSubmit(PGWPortal,null,"e");}};epay.ajaxHandle=function(er,loc){loadHandle(false);var hasError=isAjaxError(er);if(!hasError){dataBox.innerHTML=er;var str=$$(".wapbody",dataBox)?$$(".wapbody",dataBox).innerHTML:dataBox.innerHTML;popUp.show(str,true);epay.init();var inputs=inner.getElementsByTagName("input");for(var i=0,l=inputs.length;i<l;i++){if(inputs[i].type=="submit")
inputs[i].onclick=function(){if(getParentForm(inputs[i]).action.indexOf(BackUrl)!=-1)
formSubmit("action","epay_result^epay_result_detail","e");else formSubmit("action",null,"e");}}
var links=inner.getElementsByTagName("a");for(var i=0,l=links.length;i<l;i++){links[i].onclick=function(){ajax.send(this.href,epay.ajaxHandle,loadHandle,"post","","");}}
pageShow(loc,"true");}
else{errorHandle(er);}}
epay.init=function(){pageInit();var nodes=$$("#inner").getElementsByTagName('*');for(var i=0,l=nodes.length;i<l;i++){var nAction=nodes[i].getAttribute("action"),nSrc=nodes[i].getAttribute("src"),nHref=nodes[i].getAttribute("href",2);if(nAction&&nAction.indexOf("http")=="-1")nodes[i].setAttribute("action",BaseUrl+nAction);if(nSrc&&nSrc.indexOf("http")=="-1")nodes[i].setAttribute("src",BaseImgUrl+nSrc.substring(nSrc.lastIndexOf('/')+1));if(nHref&&nHref.indexOf("http")=="-1")nodes[i].setAttribute("href",BaseUrl+nHref.substring(nHref.lastIndexOf('/')+1));if(nodes[i].getAttribute("style"))nodes[i].removeAttribute("style");if(nodes[i].tagName.toLowerCase()=="input"&&nodes[i].getAttribute("type")=="submit")
{nodes[i].setAttribute("class","btns");nodes[i].setAttribute("className","btns");};if(nodes[i].tagName.toLowerCase()=="input"&&(nodes[i].getAttribute("type")=="text"||nodes[i].getAttribute("type")=="password"))
{nodes[i].setAttribute("class","textinput");nodes[i].setAttribute("className","textinput");};}}
function wyOMS(obj){var accpetPostStr=acceptOrderHandle(getPostfield(obj));var x=ajax.x();x.open("POST",SaveOrderUrl,false);x.onreadystatechange=function(){if(x.readyState==4&&x.status==200){var savePostStr=saveOrderHandle(getPostfield(x.responseText));ajax.send(PGWPortal,epay.ajaxHandle,loadHandle,"POST",savePostStr,"");}};x.setRequestHeader('Content-type','application/x-www-form-urlencoded');x.send(accpetPostStr);}
function wyOMSResult(obj,loc){var resultStr=resultHandle(getPostfield(obj));ajax.send(RETURL,innerHandle,loadHandle,"POST",resultStr,loc);}
function getPostfield(str){var temp=str.substring(str.indexOf("<go"));temp=temp.substring(0,temp.indexOf("</go>"));temp=temp.substring(temp.indexOf("<postfield"));var dds=temp.split(" ");var res=[]
for(var i=0;i<dds.length;i++){if(dds[i].indexOf("name")!="-1"||dds[i].indexOf("value")!="-1")res.push(dds[i]);}
for(var i=0;i<res.length;i++){res[i]=res[i].substring(res[i].indexOf("\"")+1,res[i].lastIndexOf("\""));}
return res;}
function acceptOrderHandle(args){var acceptOrder={'BANKID':"",'RETURL':"",'DN':"",'submit':"",'PAYMENT':"",'spMobile':"",'BANKID':"",'ORDERID':"",'rseed':"",'MERCHANTID':"",'SEED':"",'ADD_CODE':"",'CHANNEL':""}
function toStr(){var str="";for(p in acceptOrder){str+=encodeURIComponent(p)+"="+encodeURIComponent(acceptOrder[p])+"&";}
return str;}
var flag=true;for(p in acceptOrder){for(var i=0;i<args.length&&flag;i++){if(p==args[i]){acceptOrder[p]=args[i+1];flag=false;}}
flag=true;}
RETURL=acceptOrder.RETURL;return toStr();}
function saveOrderHandle(args){var saveOrder={'curCode':"",'merchantNo':"",'orderAmount':"",'orderNo':"",'orderNote':"",'orderTime':"",'orderUrl':"",'payType':"",'signData':"",'spMobile':""}
function toStr(){var str="";for(p in saveOrder){str+=encodeURIComponent(p)+"="+encodeURIComponent(saveOrder[p])+"&";}
return str;}
var flag=true;for(p in saveOrder){for(var i=0;i<args.length&&flag;i++){if(p==args[i]){saveOrder[p]=args[i+1];flag=false;}}
flag=true;}
BackUrl=saveOrder.orderUrl;return toStr();}
function resultHandle(args){var result={'BANKID':"",'MERCHANTID':"",'ORDERID':"",'PAYMENT':"",'SIGN':"",'SUCCESS':""}
function toStr(){var str="";for(p in result){str+=encodeURIComponent(p)+"="+encodeURIComponent(result[p])+"&";}
return str;}
var flag=true;for(p in result){for(var i=0;i<args.length&&flag;i++){if(p==args[i]){result[p]=args[i+1];flag=false;}}
flag=true;}
return toStr();}