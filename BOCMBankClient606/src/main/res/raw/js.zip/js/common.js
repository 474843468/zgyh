// 

﻿
var TimeOut=20000;var t=null;var TimeOutMessage="通讯超时请稍后重试。";ajax={};ajax.x=function(){try{return new ActiveXObject('Msxml2.XMLHTTP')}catch(e){try{return new ActiveXObject('Microsoft.XMLHTTP')}catch(e){return new XMLHttpRequest()}}};ajax.send=function(u,f1,f2,m,a,f1a){var x=ajax.x();if(f2)f2(x);x.open(m,u,true);x.onreadystatechange=function(){if(f1&&x.readyState==4&&x.status==200){clearTimeout(t);document.cookie=x.getResponseHeader("Set-Cookie");f1(x.responseText,f1a);}else if(f2)f2(x);};if(m.toLowerCase()=='post')x.setRequestHeader('Content-type','application/x-www-form-urlencoded');x.send(a);t=setTimeout(function(){transTimeOut(x);},TimeOut)};function transTimeOut(x){if(!x.responseText){x.abort();popUp.hidden();popUp.show(TimeOutMessage,true);}
else{return;}}
window.onload=function(){createDiv("dataBox","","");var dataSourse=$$('body').getAttribute('dataSourse');if(dataSourse!=null){var type=$$('body').getAttribute('type');if(type=="json")ajax.send(dataSourse,bingHandle,loadHandle,"GET","");else if(type=="xml")ajax.send(dataSourse,sp,loadHandle,"GET","");else ajax.send(dataSourse,bingHandle,loadHandle,"GET","");}
pageInit();}
var SimpleSelector={find:function(selector,context){var selectors=selector.split(','),elements=[],wrappers=[];if(typeof context=='string'){var wraps=SimpleSelector.find(context);wrappers=(wraps.constructor==Array)?wraps:[wraps];}else if(context&&context.constructor==Array){wrappers=context;}else{wrappers.push(context||document);}
for(var a=0,b=wrappers.length;a<b;a++){for(var x=0,y=selectors.length;x<y;x++){var s=selectors[x].replace(/ /g,''),operator=s.substr(0,1),key=s.substr(1),els=[];if(operator=='#'){els[0]=document.getElementById(key);if(els[0]&&SimpleSelector.isDescendant(els[0],wrappers[a]))
elements.push(els[0]);}else if(operator=='.'){els=SimpleSelector.getByClass(key,wrappers[a]);els=[].slice.call(els,0);elements=elements.concat(els);}else if(operator=='@'){els=SimpleSelector.getByName(key,wrappers[a]);els=[].slice.call(els,0);elements=elements.concat(els);}
else{els=wrappers[a].getElementsByTagName(s);for(var i=0,j=els.length;i<j;i++)
elements.push(els[i]);}}}
if(elements.length==0)return null;else if(elements.length==1)return elements[0];else return elements;},isDescendant:function(descendant,ancestor){return((descendant.parentNode==ancestor)||(descendant.parentNode!=document)&&arguments.callee(descendant.parentNode,ancestor));},getByClass:function(className,context){var elements=[],expr=new RegExp('\\b'+className+'\\b'),wrapper=context||document,allElements=wrapper.getElementsByTagName('*');for(var x=0,y=allElements.length;x<y;x++){if(expr.test(allElements[x].className))
elements.push(allElements[x]);}
return elements;},getByName:function(iname,context){var elements=[],expr=new RegExp('^'+iname+'$'),wrapper=context||document,allElements=wrapper.getElementsByTagName('*');for(var x=0,y=allElements.length;x<y;x++){if(expr.test(allElements[x].getAttribute("name")))
elements.push(allElements[x]);}
return elements;}};if(!window.$$)
window.$$=SimpleSelector.find;function pageInit(){var forms=document.getElementsByTagName("form");if(forms)for(var i=0;i<forms.length;i++){try{forms[i].addEventListener("submit",function(e){e.preventDefault();},false);}
catch(e){forms[i].attachEvent("onsubmit",function(event){event.returnValue=false;});}}
var as=document.getElementsByTagName("a");if(as)for(var i=0;i<as.length;i++){try{as[i].addEventListener("click",function(e){e.preventDefault();},false);}
catch(e){as[i].attachEvent("onclick",function(event){event.returnValue=false;});}}
var divs=$$("div");if(divs)for(var i=0;i<divs.length;i++){if(divs[i].getAttribute("testname")){if(divs[i].getAttribute("testname").indexOf("==")!=-1){var testKey=divs[i].getAttribute("testname").split("==")[0];var testValue=divs[i].getAttribute("testname").split("==")[1];var testFlag=$$("@"+testKey);if(testFlag&&testFlag.value==testValue)divs[i].style.display="block";else divs[i].style.display="none";}
else if(divs[i].getAttribute("testname").indexOf("!=")!=-1){var testKey=divs[i].getAttribute("testname").split("!=")[0];var testValue=divs[i].getAttribute("testname").split("!=")[1];var testFlag=$$("@"+testKey);if(testFlag&&testFlag.value!=testValue)divs[i].style.display="block";else divs[i].style.display="none";}}}}
function pageShow(card_N,flag){if(document.getElementById(card_N)){var divs=$$("div");var i,j;for(i=0;i<divs.length;i++)
{if(divs[i].getAttribute("class")=="card"||divs[i].getAttribute("className")=="card")
divs[i].style.display="none";}
document.documentElement.scrollTop=0;$$('body').scrollTop=0;document.getElementById(card_N).style.display="block";var spans=document.getElementById(card_N).getElementsByTagName("span");if(flag=="true"){var inputs=document.getElementsByTagName("input");var selects=document.getElementsByTagName("select");var temp=[];for(i=0;i<inputs.length;i++){if((inputs[i].type=="radio"||inputs[i].type=="checkbox")&&inputs[i].checked==false)continue;temp.push(inputs[i]);}
for(i=0;i<selects.length;i++){temp.push(selects[i]);}
var reshow=[];try{for(i=0;i<spans.length;i++)
{if(spans[i].getAttribute("name"))reshow.push(spans[i]);}
for(i=0;i<reshow.length;i++)
{for(j=0;j<temp.length;j++){if(temp[j].getAttribute("name")==reshow[i].getAttribute("name"))reshow[i].innerHTML=temp[j].value;}}}
catch(e){}}
else{for(i=0;i<spans.length;i++){if(spans[i].getAttribute("name"))spans[i].innerHTML="";}}
pageInit();}
else return true;};function getParentForm(obj){if(obj.tagName.toLowerCase()=="form")
return obj;else return getParentForm(obj.parentNode);}
function formSubmit(action,loc,type,targetNode){var Event=event.target||event.srcElement;var parentform=getParentForm(Event);var temp="";var inputs=parentform.getElementsByTagName("input");var selects=parentform.getElementsByTagName("select");var i=0,il=inputs.length,sl=selects.length;targetNode=targetNode||null;for(i=0;i<il;i++){if((inputs[i].type=="radio"||inputs[i].type=="checkbox")&&inputs[i].checked==false)continue;temp+=encodeURIComponent(inputs[i].name)+"="+encodeURIComponent(inputs[i].value)+"&"}
for(i=0;i<sl;i++){temp+=encodeURIComponent(selects[i].name)+"="+encodeURIComponent(selects[i].value)+"&"}
if(action=="action"||action=="")action=parentform.action;if(action=="weather")action="http://m.weather.com.cn/data/"+temp.substr(temp.indexOf("loc")+4,9)+".html"
if(action.indexOf("?")!=-1){temp+=encodeURIComponent(action.split("?")[1]);action+="&rseed="+100*Math.random();}
else{action+="?rseed="+100*Math.random();}
if(type=="b")ajax.send(action,bingHandle,loadHandle,parentform.method||"get",temp,loc);else if(type=="i")ajax.send(action,innerHandle,loadHandle,"post",temp,loc+"^"+targetNode);else if(type=="e"){if(inArray(action.substr(0,action.indexOf("?")),HomeUrl)){popUp.hidden();return;}
else if(loc=="epay_result^epay_result_detail"){popUp.hidden();if(action.indexOf("mpay.we360.com")!=-1){ajax.send(action,wyOMSResult,loadHandle,"POST",temp,loc);}
else{ajax.send(action,innerHandle,loadHandle,"POST",temp,loc);}}
else ajax.send(action,epay.ajaxHandle,loadHandle,"POST",temp,loc);}
else if(type=="w")ajax.send(action,wyOMS,loadHandle,"POST",temp,loc);};function bingHandle(obj,loc){popUp.hidden();var hasError=isAjaxError(obj);if(!hasError){if(typeof(obj)=="string"){obj=eval('('+obj+')');}
var bingDmos=$$(".databing");var i=0;for(var p in obj){if(bingDmos.constructor==Array){for(i=0;i<bingDmos.length;i++){if(bingDmos[i].getAttribute("name")==p)
dataFill(bingDmos[i],obj[p],true);}}
else{if(bingDmos.getAttribute("name")==p)
dataFill(bingDmos,obj[p],true);}
if(typeof(obj[p])=="object")bingHandle(obj[p]);}
if(obj.targetCard)loc=obj.targetCard;pageShow(loc,"true");}
else{errorHandle(obj);}}
function sp(obj){popUp.hidden();var str=obj;var temp=str.substring(str.indexOf("<go")+1);temp=temp.substring(temp.indexOf("<go"));temp=temp.substring(0,temp.indexOf("</go>"));temp=temp.substring(temp.indexOf("<postfield"));var dds=temp.split(" ");var res=[]
for(var i=0;i<dds.length;i++){if(dds[i].indexOf("name")!="-1"||dds[i].indexOf("value")!="-1")res.push(dds[i]);}
for(var i=0;i<res.length;i++){res[i]=res[i].substring(res[i].indexOf("\"")+1,res[i].lastIndexOf("\""));}
var orderObj={'curCode':" ",'merchantNo':" ",'orderAmount':" ",'orderNo':" ",'orderNote':" ",'orderTime':" ",'orderUrl':" ",'payType':" ",'signData':" ",'spMobile':" "}
for(p in orderObj){for(var i=0;i<res.length;i++){if(p==res[i])orderObj[p]=res[i+1];}}
var inputs=document.getElementsByTagName("input")
for(var p in orderObj){for(i=0;i<inputs.length;i++){if(inputs[i].getAttribute("name")==p)
dataFill(inputs[i],orderObj[p],true);}}}
function innerHandle(obj,loc){popUp.hidden();loc=loc.split("^");var tarNode=null;var hasError=isAjaxError(obj);if(!hasError){if(typeof(obj)=="string"){obj=eval('('+obj+')');}
if(document.getElementById(loc[1])){tarNode=document.getElementById(loc[1]);}
else{tarNode=document.getElementById(loc[0]);}
if(tarNode&&obj.inner)tarNode.innerHTML=obj.inner;pageInit();if(obj.targetCard)loc[0]=obj.targetCard;pageShow(loc[0],"true");}
else{errorHandle(obj);}}
function loadHandle(tranObj){var str="<img src='../../images/css/loading.gif' />";popUp.show(str,false,tranObj);}
function dataFill(node,value){var nodeType=node.tagName.toLowerCase();if(nodeType=="input"||nodeType=="select"||nodeType=="ul"||nodeType=="span"||nodeType=="img")
{switch(nodeType)
{case"input":node.value=value;break;case"select":node.options.length=0;for(var i=0,l=value.length;i<l;i++){node.options[node.options.length]=new Option(value[i].dis,value[i].value);}
break;case"img":var exName="JPG,GIF,PNF";var testStr=value.substring(value.lastIndexOf('.')+1);var key=exName.indexOf(testStr.toUpperCase());if(key!=-1){node.src="images/"+value;}
else{node.src="images/"+value+".gif";}
break;default:node.innerHTML=value;}}
else{alert(nodeType+"不支持数据绑定！");}}
function getLocation(){getJSONP('http://fw.qq.com/ipaddress',"");if(IPData)return IPData[3]?IPData[3]:IPData[2];else return null;}
function createDiv(nodeId,nodeClass,parentNode){var div=document.getElementById(nodeId);if(div)return div;div=document.createElement("div");div.setAttribute("class",nodeClass);div.setAttribute("className",nodeClass);div.setAttribute("id",nodeId);var parentNode=document.getElementById(parentNode);if(parentNode)parentNode.appendChild(div);else document.body.appendChild(div);return div;}
popUp=function(){createDiv("shadow","","");createDiv("outter","","");createDiv("inner2","","outter");createDiv("inner","","inner2");createDiv("closeBtn","","outter");createDiv("closeBtn2","rbtns","inner2")}
popUp.show=function(content,loadFlag,transObj){popUp();document.documentElement.scrollTop=0;$$('body').scrollTop=0;$$("#shadow").style.display="block";$$("#outter").style.display="block";if(!loadFlag){$$("#closeBtn2").innerHTML="取消";}
else{$$("#closeBtn2").innerHTML="确定";}
$$("#closeBtn").style.display="block";$$("#closeBtn").onclick=$$("#closeBtn2").onclick=function(){popUp.hidden();clearTimeout(t);if(transObj)transObj.abort();};$$("#inner").innerHTML=content;}
popUp.hidden=function(){popUp();$$("#shadow").style.display="none";$$("#outter").style.display="none";}
function inArray(date,array){if(array.constructor!=Array)return false;for(var i=0;i<array.length;i++){if(array[i]==date)return true;}
return false;}
function isAjaxError(ajaxData){if(typeof ajaxData!="string")return false;var ajaxDataKey="AjaxError:";if(null==ajaxData||""==ajaxData){return true;}
var checkIndex=ajaxData.indexOf(ajaxDataKey);if(-1==checkIndex){return false;}else{return true;}}
function errorHandle(ajaxData){var ajaxError="";var errorKey="AjaxError:";if(ajaxData!=null){var errorIndex=ajaxData.indexOf(errorKey);if(errorIndex!=-1){ajaxError=ajaxData.substring(errorIndex+errorKey.length);}else{}
popUp.show(ajaxError,true);}}
function FidgetAPI_takePhoto(){try{window.FidgetAPI.takePhoto();}
catch(e){window.location="FidgetAPI.takePhoto";}}
function FidgetAPI_upLoad(remoteUrl,path){try{window.FidgetAPI.upLoad(remoteUrl,path);}
catch(e){window.location="FidgetAPI.upLoad|"+remoteUrl+"|"+path;}}
function FidgetAPI_filesManager(remoteUrl){try{window.FidgetAPI.filesManager(remoteUrl);}
catch(e){window.location="FidgetAPI.filesManager|"+remoteUrl;}
return FidgetAPI.filesManagerCallBack();}
function FidgetAPI_localStorageGetItem(key){try{window.FidgetAPI.localStorageGetItem(key);}
catch(e){window.location="FidgetAPI.localStorageGetItem|"+key;}}
function FidgetAPI_localStorageSetItem(key,value){try{window.FidgetAPI.localStorageSetItem(key,value);}
catch(e){window.location="FidgetAPI.localStorageSetItem|"+key+"|"+value;}}
function FidgetAPI_localStorageRemoveItem(key){try{window.FidgetAPI.localStorageRemoveItem(key);}
catch(e){window.location="FidgetAPI.localStorageRemoveItem|"+key;}}
function FidgetAPI_localStorageClearItem(){try{window.FidgetAPI.localStorageClearItem();}
catch(e){window.location="FidgetAPI.localStorageClearItem";}}